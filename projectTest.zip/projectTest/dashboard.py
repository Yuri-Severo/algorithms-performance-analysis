import streamlit as st
import pandas as pd
import random
import plotly.express as px
from sklearn.linear_model import LinearRegression
from scipy.stats import sem, t
import plotly.graph_objects as go
import numpy as np

# Carregando dados
data_path = "../database/algoritmos_desempenho.csv"
data = pd.read_csv(data_path)

# Funções auxiliares para gráficos estilizados
def create_bar_chart(data, x, y, title, color=None):
    return px.bar(
        data, x=x, y=y, color=color, 
        title=title, 
        labels={x: x, y: y},
        template="plotly_dark"
    )

def create_pie_chart(data, names, values, title):
    return px.pie(
        data, names=names, values=values, 
        title=title, 
        hole=0.4, 
        template="plotly_dark"
    )

def create_line_chart(data, x, y, color, title):
    return px.line(
        data, x=x, y=y, color=color, 
        title=title, 
        markers=True,
        template="plotly_dark"
    )

def create_heatmap(data, title):
    return px.imshow(
        data, title=title, 
        text_auto=True, 
        color_continuous_scale="Viridis"
    )

# Cálculos gerais
total_records = data["id"].count()
total_time_hours = "{:,.2f}".format(data["Tempo(ms)"].sum() / 3600000).replace(",", "X").replace(".", ",").replace("X", ".")


# Gráficos principais
time_by_scenario_fig = create_bar_chart(data, x="Cenario", y="Tempo(ms)", title="Tempo por Cenário")
time_by_algorithm_fig = create_pie_chart(
    data.groupby("Algoritmo")["Tempo(ms)"].sum().reset_index(), 
    names="Algoritmo", 
    values="Tempo(ms)", 
    title="Tempo por Algoritmo"
)
time_by_computer_fig = create_bar_chart(data, x="Computador", y="Tempo(ms)", title="Tempo por Computador")

pivot_data = pd.pivot_table(data, values="Tempo(ms)", index="Cenario", columns="Algoritmo", aggfunc="mean")
time_heatmap_fig = create_heatmap(pivot_data, title="Correlação entre Cenário e Algoritmo")

algo_sample_data = data.groupby(["Amostra", "Algoritmo"])["Tempo(ms)"].mean().reset_index()
algorithm_by_sample_fig = create_line_chart(algo_sample_data, x="Amostra", y="Tempo(ms)", color="Algoritmo", title="Impacto do Algoritmo na Amostra")

algorithm_exec_count = data["Algoritmo"].value_counts().reset_index()
algorithm_exec_count.columns = ["Algoritmo", "Execuções"]
exec_pie_fig = create_pie_chart(algorithm_exec_count, names="Algoritmo", values="Execuções", title="Execuções por Algoritmo")

# Configuração do layout
def setup_layout():
    st.set_page_config(layout="wide", page_title="Análise de Algoritmos")
    st.title("Análise de Desempenho de Algoritmos")

setup_layout()

tab_overview, tab_interactive = st.tabs(["Visão Geral", "Análises Interativas"])

# Tab Visão Geral
with tab_overview:
    col1, col2 = st.columns(2)
    col3, col4, col5 = st.columns(3)
    
    col1.metric("Total de Registros", total_records)
    col2.metric("Tempo Total (h)", total_time_hours)

    col3.plotly_chart(time_by_scenario_fig, use_container_width=True)
    col4.plotly_chart(time_by_algorithm_fig, use_container_width=True)
    col5.plotly_chart(time_by_computer_fig, use_container_width=True)

    col6, col7 = st.columns(2)
    col6.plotly_chart(time_heatmap_fig, use_container_width=True)
    col7.plotly_chart(exec_pie_fig, use_container_width=True)

# Tab Análises Interativas
with tab_interactive:
    st.subheader("Filtros")
    col1, col2, col3 = st.columns(3)
    
    selected_algorithm = col1.selectbox("Algoritmo", data["Algoritmo"].unique())
    selected_scenario = col2.selectbox("Cenário", data["Cenario"].unique())
    selected_sample = col3.selectbox("Amostra", data["Amostra"].unique())

    filtered_data = data[
        (data["Algoritmo"] == selected_algorithm) &
        (data["Cenario"] == selected_scenario) &
        (data["Amostra"] == selected_sample)
    ]

    col4, col5 = st.columns(2)
    col4.metric("Tempo Máximo (ms)", filtered_data["Tempo(ms)"].max())
    col5.metric("Tempo Médio (ms)", "{:,.2f}".format(filtered_data["Tempo(ms)"].mean()).replace(",", "X").replace(".", ",").replace("X", "."))

    col6, col7,col8 = st.columns(3)
    
    # Gráfico de regressão linear
    x = np.arange(len(filtered_data)).reshape(-1, 1)
    y = filtered_data["Tempo(ms)"].values

    model = LinearRegression()
    model.fit(x, y)
    predictions = model.predict(x)

    regression_fig = px.scatter(
        filtered_data, x=x.flatten(), y="Tempo(ms)",
        title="Regressão Linear", 
        labels={"x": "Índice", "Tempo(ms)": "Tempo (ms)"},
        template="plotly_dark"
    )
    regression_fig.add_scatter(x=x.flatten(), y=predictions, mode="lines", name="Linha de Regressão")
    col6.plotly_chart(regression_fig, use_container_width=True)

    comparison_data = data[
    (data["Algoritmo"] == selected_algorithm) &
    (data["Amostra"] == selected_sample)
    ].groupby("Cenario")["Tempo(ms)"].mean().reset_index()

    comparison_bar_fig = create_bar_chart(
        comparison_data, 
        x="Cenario", 
        y="Tempo(ms)", 
        title=f"Comparação de Tempo por Cenário ({selected_algorithm}, Amostra: {selected_sample})"
    )

    col7.plotly_chart(comparison_bar_fig, use_container_width=True)

    # Intervalo de confiança
    grouped = filtered_data.groupby("Computador")["Tempo(ms)"]
    mean_times = grouped.mean()
    std_errors = grouped.apply(sem)
    degrees_freedom = grouped.count() - 1
    confidence_intervals = t.ppf(0.975, degrees_freedom) * std_errors

    ci_fig = go.Figure()
    for computer in mean_times.index:
        ci_fig.add_trace(go.Bar(
            x=[computer], y=[mean_times[computer]],
            error_y=dict(
                type="data",
                array=[confidence_intervals[computer]],
                visible=True
            )
        ))
    ci_fig.update_layout(
        title="Média e Intervalo de Confiança",
        xaxis_title="Computador", yaxis_title="Tempo (ms)",
        template="plotly_dark"
    )
    col8.plotly_chart(ci_fig, use_container_width=True)
